[![Actions Status](https://github.com/localh0rst/Loggly/actions/workflows/test.yml/badge.svg)](https://github.com/localh0rst/Loggly/actions)
# NAME

Loggly - It's new $module

# SYNOPSIS

    use Loggly;

# DESCRIPTION

Loggly is ...

# LICENSE

Copyright (C) localh0rst.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

localh0rst <git@fail.ninja>
