package Loggly;
use 5.008001;
use strict;
use warnings;
use OpenSearch;
our $VERSION = "0.01";

1;
__END__

=encoding utf-8

=head1 NAME

Loggly - It's new $module

=head1 SYNOPSIS

    use Loggly;

=head1 DESCRIPTION

Loggly is ...

=head1 LICENSE

Copyright (C) localh0rst.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 AUTHOR

localh0rst E<lt>git@fail.ninjaE<gt>

=cut

